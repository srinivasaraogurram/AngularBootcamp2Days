import { Injectable } from '@angular/core';
//
@Injectable({
  providedIn: 'root'
})
//
export class ProfileService {

  constructor() { }
  login(){
    return true;
  }
  logout(){
    return false;
  }
  status(){}


}
