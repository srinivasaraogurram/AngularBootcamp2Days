import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute } from "@angular/router";
//
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
//
export class AdminComponent implements OnInit{
  //message : {};
  allAdmins : any = [];
  //
  @Input() isAdminResolved : [] = [];
  ngOnInit(): void {
    this.allAdmins = this.isAdminResolved;
  }
  //
  //constructor(private activatedRoute : ActivatedRoute) {
    //this.allAdmins = this.activatedRoute.snapshot.data["isAdminResolved"];
    //console.log(this.allAdmins);    
  //}
}
